# Derby Golf Tournament

Official website for the Derby Golf Tournament at Valley View Golf Course.

## Format
- **Qualifier:** 18-hole best-ball scramble, 36 teams, 2 teams per hole
- **Championship Derby:** Top 10 teams, alternate shot, single elimination, 9 holes

## Deploy
Drop the contents of this repo onto any static host:
- **Netlify:** drag-and-drop the folder at app.netlify.com/drop
- **Vercel:** import the GitHub repo
- **Cloudflare Pages:** import the GitHub repo

## Contact
derbygolftournaments@gmail.com
